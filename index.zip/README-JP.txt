GIF → WebM / Sprite Sheet Converter v0.3

この版は、前版の「@ffmpeg/ffmpeg をCDNから直接importしてWorkerを作る」方式をやめ、
Viteで @ffmpeg/ffmpeg をアプリ本体へバンドルします。

■ GitHub Pagesで使う
1. このZIPを展開
2. 中身を新しいGitHubリポジトリへアップロード
3. Settings → Pages → Source を「GitHub Actions」にする
4. mainブランチへpushすると自動ビルド・公開

■ Macでローカル確認
Node.js 22以降で:
npm install
npm run dev

表示された localhost URL をChromeで開いてください。
index.htmlをダブルクリック(file://)して使う構成ではありません。

■ 出力
Transparent WebM:
  VP9 + yuva420p + auto-alt-ref 0

Sprite:
  xxx-sprite.png
  xxx-sprite.json

※ 初回変換時、FFmpeg Core/WASMをCDNから読み込みます。
